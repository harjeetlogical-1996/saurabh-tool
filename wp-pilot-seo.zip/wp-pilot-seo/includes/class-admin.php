<?php
/**
 * Admin menu page: onboarding / getting started + a "check for updates" button.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WPPSEO_Admin {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	const PILOT_URL = 'https://wp-mcp-production.up.railway.app';

	private function __construct() {
		add_action( 'admin_menu', array( $this, 'menu' ) );
		add_action( 'admin_post_wppseo_check_update', array( $this, 'handle_check_update' ) );
		add_action( 'admin_post_wppseo_connect', array( $this, 'handle_connect' ) );
		add_action( 'admin_post_wppseo_disconnect', array( $this, 'handle_disconnect' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'assets' ) );
	}

	/**
	 * One-click connect: create an Application Password for this admin, then
	 * hand it off to WP Pilot which logs the user in and stores the site.
	 */
	public function handle_connect() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Not allowed', 'wp-pilot-seo' ) );
		}
		check_admin_referer( 'wppseo_connect' );

		if ( ! class_exists( 'WP_Application_Passwords' ) ) {
			wp_safe_redirect( admin_url( 'admin.php?page=wp-pilot-seo&connect_err=app_passwords_unavailable' ) );
			exit;
		}

		$user = wp_get_current_user();
		// Remove an old WP Pilot password if present (avoid duplicates).
		$existing = WP_Application_Passwords::get_user_application_passwords( $user->ID );
		foreach ( (array) $existing as $item ) {
			if ( isset( $item['name'] ) && 'WP Pilot' === $item['name'] ) {
				WP_Application_Passwords::delete_application_password( $user->ID, $item['uuid'] );
			}
		}

		$created = WP_Application_Passwords::create_new_application_password(
			$user->ID,
			array( 'name' => 'WP Pilot' )
		);
		if ( is_wp_error( $created ) ) {
			wp_safe_redirect( admin_url( 'admin.php?page=wp-pilot-seo&connect_err=create_failed' ) );
			exit;
		}
		$app_pw = $created[0]; // plaintext, shown once

		// Hand off to WP Pilot. It will log the user in / sign up, then store the site.
		$return = admin_url( 'admin.php?page=wp-pilot-seo&connected=1' );
		$args   = array(
			'site'   => home_url(),
			'user'   => $user->user_login,
			'pw'     => $app_pw,
			'email'  => $user->user_email,
			'return' => $return,
		);
		$url = self::PILOT_URL . '/connect?' . http_build_query( $args );
		wp_redirect( $url );
		exit;
	}

	public function handle_disconnect() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Not allowed', 'wp-pilot-seo' ) );
		}
		check_admin_referer( 'wppseo_disconnect' );
		$user = wp_get_current_user();
		if ( class_exists( 'WP_Application_Passwords' ) ) {
			$existing = WP_Application_Passwords::get_user_application_passwords( $user->ID );
			foreach ( (array) $existing as $item ) {
				if ( isset( $item['name'] ) && 'WP Pilot' === $item['name'] ) {
					WP_Application_Passwords::delete_application_password( $user->ID, $item['uuid'] );
				}
			}
		}
		delete_option( 'wppseo_connected' );
		wp_safe_redirect( admin_url( 'admin.php?page=wp-pilot-seo&disconnected=1' ) );
		exit;
	}

	private function is_connected() {
		return (bool) get_option( 'wppseo_connected' );
	}

	public function menu() {
		add_menu_page(
			__( 'WP Pilot SEO', 'wp-pilot-seo' ),
			__( 'WP Pilot SEO', 'wp-pilot-seo' ),
			'manage_options',
			'wp-pilot-seo',
			array( $this, 'render' ),
			'dashicons-chart-line',
			58
		);
	}

	public function assets( $hook ) {
		if ( 'toplevel_page_wp-pilot-seo' !== $hook ) {
			return;
		}
		wp_enqueue_style( 'wppseo-admin', WPPSEO_URL . 'admin.css', array(), WPPSEO_VERSION );
	}

	/** Force an update check, then bounce back. */
	public function handle_check_update() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Not allowed', 'wp-pilot-seo' ) );
		}
		check_admin_referer( 'wppseo_check_update' );
		delete_transient( 'wppseo_update_check' );
		delete_site_transient( 'update_plugins' ); // make WP re-poll
		wp_update_plugins();
		wp_safe_redirect( admin_url( 'admin.php?page=wp-pilot-seo&checked=1' ) );
		exit;
	}

	public function render() {
		$sitemap   = home_url( '/wppseo-sitemap.xml' );
		$connect   = 'https://wp-mcp-production.up.railway.app/mcp';
		$site_url  = home_url();
		$app_pw    = admin_url( 'profile.php#application-passwords-section' );

		// Update status.
		$update_available = false;
		$new_version      = '';
		$updates = get_site_transient( 'update_plugins' );
		$basename = plugin_basename( WPPSEO_FILE );
		if ( $updates && isset( $updates->response[ $basename ] ) ) {
			$update_available = true;
			$new_version      = $updates->response[ $basename ]->new_version;
		}
		$just_checked = isset( $_GET['checked'] );

		// Mark connected when WP Pilot redirects back.
		if ( isset( $_GET['connected'] ) ) {
			update_option( 'wppseo_connected', 1 );
		}
		if ( isset( $_GET['disconnected'] ) ) {
			delete_option( 'wppseo_connected' );
		}
		$connected   = $this->is_connected();
		$connect_err = isset( $_GET['connect_err'] ) ? sanitize_text_field( wp_unslash( $_GET['connect_err'] ) ) : '';
		?>
		<div class="wrap wppseo-page">
			<h1 style="display:flex;align-items:center;gap:10px">
				<span class="dashicons dashicons-chart-line" style="font-size:30px;width:30px;height:30px;color:#22C55E"></span>
				<?php esc_html_e( 'WP Pilot SEO', 'wp-pilot-seo' ); ?>
				<span style="font-size:13px;color:#646970;font-weight:400">v<?php echo esc_html( WPPSEO_VERSION ); ?></span>
			</h1>

			<div class="wppseo-cards">

				<!-- Onboarding -->
				<div class="wppseo-card">
					<h2><?php esc_html_e( '1. You\'re all set for on-site SEO', 'wp-pilot-seo' ); ?></h2>
					<p><?php esc_html_e( 'Edit any post or page — the "WP Pilot SEO" box appears below the editor. Set a focus keyword, SEO title and meta description, and watch your live SEO score.', 'wp-pilot-seo' ); ?></p>
					<ul class="wppseo-list">
						<li><?php esc_html_e( 'Meta title, description & focus keyword', 'wp-pilot-seo' ); ?></li>
						<li><?php esc_html_e( 'Schema (Article, FAQ, Breadcrumb & more)', 'wp-pilot-seo' ); ?></li>
						<li><?php esc_html_e( 'Open Graph & Twitter cards', 'wp-pilot-seo' ); ?></li>
						<li>
							<?php
							printf(
								/* translators: %s: sitemap URL */
								esc_html__( 'XML sitemap: %s', 'wp-pilot-seo' ),
								'<a href="' . esc_url( $sitemap ) . '" target="_blank" rel="noopener">' . esc_html( $sitemap ) . '</a>'
							);
							?>
						</li>
					</ul>
				</div>

				<!-- Connect to AI (one-click) -->
				<div class="wppseo-card">
					<h2><?php esc_html_e( '2. Connect to AI', 'wp-pilot-seo' ); ?></h2>
					<p><?php esc_html_e( 'Let Claude or ChatGPT write articles, generate images and manage SEO on this site — automatically.', 'wp-pilot-seo' ); ?></p>

					<?php if ( $connect_err ) : ?>
						<p class="wppseo-badge update"><?php
							if ( 'app_passwords_unavailable' === $connect_err ) {
								esc_html_e( 'Application Passwords are disabled on this site. Enable them (needs HTTPS) to connect.', 'wp-pilot-seo' );
							} else {
								esc_html_e( 'Could not create the connection. Please try again.', 'wp-pilot-seo' );
							}
						?></p>
					<?php endif; ?>

					<?php if ( $connected ) : ?>
						<p class="wppseo-badge ok"><?php esc_html_e( 'Connected to WP Pilot.', 'wp-pilot-seo' ); ?></p>
						<p><?php esc_html_e( 'Now add this connector URL in Claude / ChatGPT:', 'wp-pilot-seo' ); ?></p>
						<div class="wppseo-code">
							<code><?php echo esc_html( $connect ); ?></code>
							<button type="button" class="button" onclick="navigator.clipboard.writeText('<?php echo esc_js( $connect ); ?>');this.textContent='<?php echo esc_js( __( 'Copied', 'wp-pilot-seo' ) ); ?>'"><?php esc_html_e( 'Copy', 'wp-pilot-seo' ); ?></button>
						</div>
						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:12px">
							<input type="hidden" name="action" value="wppseo_disconnect">
							<?php wp_nonce_field( 'wppseo_disconnect' ); ?>
							<button type="submit" class="button button-link-delete"><?php esc_html_e( 'Disconnect', 'wp-pilot-seo' ); ?></button>
						</form>
					<?php else : ?>
						<p><?php esc_html_e( 'One click sets everything up — we create a secure Application Password for you automatically. No copy-paste.', 'wp-pilot-seo' ); ?></p>
						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:12px">
							<input type="hidden" name="action" value="wppseo_connect">
							<?php wp_nonce_field( 'wppseo_connect' ); ?>
							<button type="submit" class="button button-primary button-hero"><?php esc_html_e( 'Connect to WP Pilot', 'wp-pilot-seo' ); ?></button>
						</form>
					<?php endif; ?>
				</div>

				<!-- Updates -->
				<div class="wppseo-card">
					<h2><?php esc_html_e( '3. Updates', 'wp-pilot-seo' ); ?></h2>
					<?php if ( $update_available ) : ?>
						<p class="wppseo-badge update"><?php
							printf( esc_html__( 'Update available: v%s', 'wp-pilot-seo' ), esc_html( $new_version ) );
						?></p>
						<p><a class="button button-primary" href="<?php echo esc_url( admin_url( 'plugins.php' ) ); ?>"><?php esc_html_e( 'Go to Plugins to update', 'wp-pilot-seo' ); ?></a></p>
					<?php else : ?>
						<p class="wppseo-badge ok"><?php
							echo $just_checked
								? esc_html__( 'You\'re on the latest version.', 'wp-pilot-seo' )
								: esc_html__( 'Updates install automatically when available.', 'wp-pilot-seo' );
						?></p>
					<?php endif; ?>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:10px">
						<input type="hidden" name="action" value="wppseo_check_update">
						<?php wp_nonce_field( 'wppseo_check_update' ); ?>
						<button type="submit" class="button"><?php esc_html_e( 'Check for updates now', 'wp-pilot-seo' ); ?></button>
					</form>
				</div>

			</div>
		</div>

		<style>
			.wppseo-page .wppseo-cards{display:grid;gap:20px;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));max-width:1100px;margin-top:20px}
			.wppseo-page .wppseo-card{background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:22px}
			.wppseo-page .wppseo-card h2{margin-top:0;font-size:17px}
			.wppseo-page .wppseo-list,.wppseo-page .wppseo-steps{margin:14px 0;padding-left:20px}
			.wppseo-page .wppseo-list li,.wppseo-page .wppseo-steps li{margin:7px 0}
			.wppseo-page .wppseo-code{display:flex;gap:8px;align-items:center;background:#f6f7f7;border:1px solid #dcdcde;border-radius:6px;padding:8px 10px;margin-top:10px}
			.wppseo-page .wppseo-code code{flex:1;word-break:break-all;background:none;font-size:12px}
			.wppseo-page .wppseo-badge{display:inline-block;padding:6px 12px;border-radius:999px;font-weight:600;font-size:13px}
			.wppseo-page .wppseo-badge.ok{background:#edfaef;color:#00a32a}
			.wppseo-page .wppseo-badge.update{background:#fcf3e6;color:#bd7b00}
		</style>
		<?php
	}
}
