=== wptaskify ===
Contributors: wptaskify
Tags: seo, meta, schema, sitemap, open graph, ai
Requires at least: 5.6
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.5.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Free, full-featured SEO for WordPress: meta titles & descriptions, focus
keywords, schema/structured data, Open Graph, Twitter cards, XML sitemap and
an SEO score. Optionally connects to AI assistants via wptaskify.

== Description ==

wptaskify SEO gives you everything a premium SEO plugin does, for free:

* SEO title & meta description with a live Google-style snippet preview
* Focus keyword + secondary keywords with a real-time SEO score
* Open Graph (Facebook) and Twitter Card tags
* Canonical URLs and noindex control
* JSON-LD structured data: Organization, WebSite, Breadcrumb, Article,
  Product, FAQPage, HowTo
* Automatic XML sitemap
* Full REST API so AI assistants (Claude & ChatGPT) can read & write your SEO
  through the wptaskify connector

== Installation ==

1. Upload the `wp-pilot-seo` folder to `/wp-content/plugins/`.
2. Activate it from the Plugins screen.
3. Edit any post or page — the wptaskify SEO box appears below the editor.

== Changelog ==

= 1.0.0 =
* Initial release.
