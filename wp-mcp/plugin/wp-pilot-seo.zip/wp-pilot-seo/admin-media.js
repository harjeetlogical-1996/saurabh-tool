/* wptaskify SEO - media picker for the logo / default OG image fields. */
( function ( $ ) {
	'use strict';

	$( function () {
		$( '.wppseo-media' ).each( function () {
			var $wrap    = $( this );
			var $input   = $wrap.find( 'input[type="hidden"]' );
			var $preview = $wrap.find( '.wppseo-media-preview' );
			var $clear   = $wrap.find( '.wppseo-media-clear' );
			var frame    = null;

			$wrap.find( '.wppseo-media-pick' ).on( 'click', function ( e ) {
				e.preventDefault();
				if ( frame ) {
					frame.open();
					return;
				}
				frame = wp.media( {
					title: 'Select image',
					library: { type: 'image' },
					button: { text: 'Use this image' },
					multiple: false
				} );
				frame.on( 'select', function () {
					var att = frame.state().get( 'selection' ).first().toJSON();
					$input.val( att.id );
					var url = att.sizes && att.sizes.thumbnail ? att.sizes.thumbnail.url : att.url;
					$preview.attr( 'src', url ).show();
					$clear.show();
				} );
				frame.open();
			} );

			$clear.on( 'click', function ( e ) {
				e.preventDefault();
				$input.val( '' );
				$preview.attr( 'src', '' ).hide();
				$clear.hide();
			} );
		} );
	} );
} )( jQuery );
