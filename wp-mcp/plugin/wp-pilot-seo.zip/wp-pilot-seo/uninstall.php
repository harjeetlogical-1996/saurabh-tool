<?php
/**
 * Clean up wptaskify data on uninstall.
 */
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

global $wpdb;
// Delete all _wppseo_* post meta (esc_like + prepare for safe LIKE matching).
$like = $wpdb->esc_like( '_wppseo_' ) . '%';
$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->postmeta} WHERE meta_key LIKE %s", $like ) );

// Clean up our own options too (leave user content alone).
foreach ( array( 'wpps_custom_css', 'wpps_robots_txt', 'wpps_llms_txt', 'wppseo_activity_log',
	'wppseo_connected', 'wpps_previous_theme', 'wppseo_update_check' ) as $opt ) {
	delete_option( $opt );
}
// Note: wppseo_backup_suffix is intentionally kept so existing backups stay reachable.
