<?php
/**
 * Visual breadcrumbs (Batch 4): a [wptaskify_breadcrumbs] shortcode + matching
 * Gutenberg block that renders a Home > Category > Page trail. WordPress ships no
 * visual breadcrumb, so themes either roll their own or go without - this fills
 * that gap. The BreadcrumbList *schema* is emitted separately by WPPSEO_Schema;
 * this is the on-page, human-visible trail.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WPPSEO_Breadcrumbs {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_shortcode( 'wptaskify_breadcrumbs', array( $this, 'shortcode' ) );
		add_action( 'init', array( $this, 'register_block' ) );
	}

	/** Safe term link: returns a URL string, or null if get_term_link errored.
	 * (get_term_link can return WP_Error, which is truthy - passing it to esc_url
	 * fatals under PHP 8, so we must guard it here.) */
	private function term_url( $term ) {
		$url = get_term_link( $term );
		return ( is_wp_error( $url ) || ! is_string( $url ) ) ? null : $url;
	}

	/** Build the ordered trail as [ [label, url|null], ... ] for the current view. */
	private function trail() {
		$items = array();
		$items[] = array( __( 'Home', 'wp-pilot-seo' ), home_url( '/' ) );

		if ( is_singular() ) {
			$post_id = get_queried_object_id();
			$ptype   = get_post_type( $post_id );

			// For posts, include the primary category in the trail.
			if ( 'post' === $ptype ) {
				$cats = get_the_category( $post_id );
				if ( ! empty( $cats ) ) {
					$cat = $cats[0];
					// Walk up the category ancestors (top-most first).
					$ancestors = array_reverse( get_ancestors( $cat->term_id, 'category' ) );
					foreach ( $ancestors as $anc_id ) {
						$anc = get_term( $anc_id, 'category' );
						if ( $anc && ! is_wp_error( $anc ) ) {
							$items[] = array( $anc->name, $this->term_url( $anc ) );
						}
					}
					$items[] = array( $cat->name, $this->term_url( $cat ) );
				}
			} elseif ( 'page' === $ptype ) {
				// For hierarchical pages, include parent pages.
				foreach ( array_reverse( get_post_ancestors( $post_id ) ) as $anc_id ) {
					$items[] = array( get_the_title( $anc_id ), get_permalink( $anc_id ) );
				}
			}
			$items[] = array( get_the_title( $post_id ), null ); // current, no link

		} elseif ( is_category() || is_tag() || is_tax() ) {
			$term = get_queried_object();
			if ( $term && isset( $term->taxonomy ) ) {
				$ancestors = array_reverse( get_ancestors( $term->term_id, $term->taxonomy ) );
				foreach ( $ancestors as $anc_id ) {
					$anc = get_term( $anc_id, $term->taxonomy );
					if ( $anc && ! is_wp_error( $anc ) ) {
						$items[] = array( $anc->name, $this->term_url( $anc ) );
					}
				}
				$items[] = array( single_term_title( '', false ), null );
			}
		} elseif ( is_author() ) {
			$items[] = array( get_the_author_meta( 'display_name', (int) get_query_var( 'author' ) ), null );
		} elseif ( is_search() ) {
			$items[] = array( sprintf( __( 'Search: %s', 'wp-pilot-seo' ), get_search_query() ), null );
		} elseif ( is_year() || is_month() || is_day() ) {
			$items[] = array( get_the_archive_title(), null );
		} elseif ( is_404() ) {
			$items[] = array( __( 'Not found', 'wp-pilot-seo' ), null );
		} elseif ( is_home() && ! is_front_page() ) {
			$items[] = array( get_the_title( get_option( 'page_for_posts' ) ), null );
		}

		return $items;
	}

	/** Render the visual breadcrumb trail. */
	public function shortcode( $atts = array() ) {
		// Never render on the front page (nothing to trace to).
		if ( is_front_page() ) {
			return '';
		}
		$atts = shortcode_atts(
			array( 'separator' => '/', 'label' => __( 'Breadcrumb', 'wp-pilot-seo' ) ),
			$atts,
			'wptaskify_breadcrumbs'
		);
		$items = $this->trail();
		if ( count( $items ) < 2 ) {
			return '';
		}

		$sep  = '<span class="wppseo-bc-sep" aria-hidden="true"> ' . esc_html( $atts['separator'] ) . ' </span>';
		$out  = '<nav class="wppseo-breadcrumbs" aria-label="' . esc_attr( $atts['label'] ) . '">';
		$out .= '<ol>';
		$last = count( $items ) - 1;
		foreach ( $items as $i => $item ) {
			list( $label, $url ) = $item;
			$label = (string) $label;
			$out  .= '<li>';
			if ( $url && $i !== $last ) {
				$out .= '<a href="' . esc_url( $url ) . '">' . esc_html( $label ) . '</a>';
			} else {
				$out .= '<span aria-current="page">' . esc_html( $label ) . '</span>';
			}
			$out .= '</li>';
			if ( $i !== $last ) {
				$out .= $sep;
			}
		}
		$out .= '</ol></nav>';

		// Minimal styling (scoped to our class).
		$out .= '<style>.wppseo-breadcrumbs{font-size:.9em;margin:0 0 16px}.wppseo-breadcrumbs ol{list-style:none;margin:0;padding:0;display:flex;flex-wrap:wrap;align-items:center}.wppseo-breadcrumbs li{display:inline}.wppseo-breadcrumbs a{text-decoration:none}.wppseo-breadcrumbs a:hover{text-decoration:underline}.wppseo-bc-sep{color:#888;margin:0 2px}</style>';

		return $out;
	}

	/**
	 * Register a simple dynamic block that renders the same shortcode. Uses PHP
	 * registration only (no build step / JS bundle) so the block works everywhere.
	 */
	public function register_block() {
		if ( ! function_exists( 'register_block_type' ) ) {
			return;
		}
		register_block_type(
			'wptaskify/breadcrumbs',
			array(
				'api_version'     => 2,
				'title'           => __( 'wptaskify Breadcrumbs', 'wp-pilot-seo' ),
				'category'        => 'widgets',
				'icon'            => 'arrow-right-alt2',
				'render_callback' => array( $this, 'render_block' ),
				'attributes'      => array(
					'separator' => array( 'type' => 'string', 'default' => '/' ),
				),
			)
		);
	}

	/** Block render callback -> reuse the shortcode. */
	public function render_block( $attributes ) {
		$sep = isset( $attributes['separator'] ) ? $attributes['separator'] : '/';
		return $this->shortcode( array( 'separator' => $sep ) );
	}
}
