<?php
/**
 * Archive SEO (Batch 2): editable meta title + description for term archives
 * (categories, tags, custom taxonomies) and author archives. WordPress creates
 * these archive PAGES but gives them no SEO meta - that's this class's job.
 *
 * Storage is native WP meta:
 *   - term archives   -> term meta  `_wppseo_title` / `_wppseo_description`
 *   - author archives -> user meta  `_wppseo_title` / `_wppseo_description`
 *
 * Adds fields to every taxonomy term-edit screen and the user profile screen,
 * and exposes read/write helpers used by the frontend + REST/AI layer.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WPPSEO_Archive_SEO {

	const META_TITLE = '_wppseo_title';
	const META_DESC  = '_wppseo_description';

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		// Term fields: add to the EDIT screen of every public taxonomy.
		add_action( 'admin_init', array( $this, 'hook_taxonomies' ) );
		// Save term fields.
		add_action( 'edited_term', array( $this, 'save_term' ), 10, 3 );
		add_action( 'created_term', array( $this, 'save_term' ), 10, 3 );
		// Author (user) fields.
		add_action( 'show_user_profile', array( $this, 'user_fields' ) );
		add_action( 'edit_user_profile', array( $this, 'user_fields' ) );
		add_action( 'personal_options_update', array( $this, 'save_user' ) );
		add_action( 'edit_user_profile_update', array( $this, 'save_user' ) );
	}

	// ---- Term archives --------------------------------------------------

	public function hook_taxonomies() {
		$taxes = get_taxonomies( array( 'public' => true ), 'names' );
		foreach ( $taxes as $tax ) {
			add_action( "{$tax}_edit_form_fields", array( $this, 'term_fields' ), 10, 2 );
		}
	}

	/** Render title/description fields on a term-edit screen. */
	public function term_fields( $term ) {
		$title = get_term_meta( $term->term_id, self::META_TITLE, true );
		$desc  = get_term_meta( $term->term_id, self::META_DESC, true );
		wp_nonce_field( 'wppseo_term_' . $term->term_id, 'wppseo_term_nonce' );
		?>
		<tr class="form-field">
			<th scope="row"><label for="wppseo_title"><?php esc_html_e( 'SEO title', 'wp-pilot-seo' ); ?></label></th>
			<td>
				<input name="wppseo_title" id="wppseo_title" type="text" value="<?php echo esc_attr( $title ); ?>" size="40">
				<p class="description"><?php esc_html_e( 'Title tag for this archive page. Blank = theme default.', 'wp-pilot-seo' ); ?></p>
			</td>
		</tr>
		<tr class="form-field">
			<th scope="row"><label for="wppseo_description"><?php esc_html_e( 'Meta description', 'wp-pilot-seo' ); ?></label></th>
			<td>
				<textarea name="wppseo_description" id="wppseo_description" rows="3" cols="50"><?php echo esc_textarea( $desc ); ?></textarea>
				<p class="description"><?php esc_html_e( 'Meta description for this archive page (aim for 150-160 characters).', 'wp-pilot-seo' ); ?></p>
			</td>
		</tr>
		<?php
	}

	/** Save term fields. */
	public function save_term( $term_id, $tt_id = 0, $taxonomy = '' ) {
		if ( ! current_user_can( 'manage_categories' ) ) {
			return;
		}
		$nonce = isset( $_POST['wppseo_term_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['wppseo_term_nonce'] ) ) : '';
		if ( ! $nonce || ! wp_verify_nonce( $nonce, 'wppseo_term_' . $term_id ) ) {
			return;
		}
		if ( isset( $_POST['wppseo_title'] ) ) {
			update_term_meta( $term_id, self::META_TITLE, sanitize_text_field( wp_unslash( $_POST['wppseo_title'] ) ) );
		}
		if ( isset( $_POST['wppseo_description'] ) ) {
			update_term_meta( $term_id, self::META_DESC, sanitize_textarea_field( wp_unslash( $_POST['wppseo_description'] ) ) );
		}
	}

	// ---- Author archives ------------------------------------------------

	/** Render title/description fields on the user profile screen. */
	public function user_fields( $user ) {
		if ( ! current_user_can( 'edit_user', $user->ID ) ) {
			return;
		}
		$title = get_user_meta( $user->ID, self::META_TITLE, true );
		$desc  = get_user_meta( $user->ID, self::META_DESC, true );
		wp_nonce_field( 'wppseo_user_' . $user->ID, 'wppseo_user_nonce' );
		?>
		<h2><?php esc_html_e( 'Author archive SEO (wptaskify)', 'wp-pilot-seo' ); ?></h2>
		<table class="form-table" role="presentation">
			<tr>
				<th><label for="wppseo_user_title"><?php esc_html_e( 'SEO title', 'wp-pilot-seo' ); ?></label></th>
				<td><input name="wppseo_title" id="wppseo_user_title" type="text" class="regular-text" value="<?php echo esc_attr( $title ); ?>">
					<p class="description"><?php esc_html_e( "Title tag for this author's archive page.", 'wp-pilot-seo' ); ?></p></td>
			</tr>
			<tr>
				<th><label for="wppseo_user_desc"><?php esc_html_e( 'Meta description', 'wp-pilot-seo' ); ?></label></th>
				<td><textarea name="wppseo_description" id="wppseo_user_desc" rows="3" class="regular-text"><?php echo esc_textarea( $desc ); ?></textarea></td>
			</tr>
		</table>
		<?php
	}

	/** Save user fields. */
	public function save_user( $user_id ) {
		if ( ! current_user_can( 'edit_user', $user_id ) ) {
			return;
		}
		$nonce = isset( $_POST['wppseo_user_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['wppseo_user_nonce'] ) ) : '';
		if ( ! $nonce || ! wp_verify_nonce( $nonce, 'wppseo_user_' . $user_id ) ) {
			return;
		}
		if ( isset( $_POST['wppseo_title'] ) ) {
			update_user_meta( $user_id, self::META_TITLE, sanitize_text_field( wp_unslash( $_POST['wppseo_title'] ) ) );
		}
		if ( isset( $_POST['wppseo_description'] ) ) {
			update_user_meta( $user_id, self::META_DESC, sanitize_textarea_field( wp_unslash( $_POST['wppseo_description'] ) ) );
		}
	}

	// ---- Frontend read helpers (used by class-frontend) -----------------

	/**
	 * Resolve the SEO title/description for the CURRENT archive query. Returns
	 * array( 'title' => ..., 'description' => ... ) with empty strings if none set
	 * or if this isn't a term/author archive.
	 */
	public static function current() {
		$out = array( 'title' => '', 'description' => '' );
		if ( is_category() || is_tag() || is_tax() ) {
			$term = get_queried_object();
			if ( $term && isset( $term->term_id ) ) {
				$out['title']       = (string) get_term_meta( $term->term_id, self::META_TITLE, true );
				$out['description'] = (string) get_term_meta( $term->term_id, self::META_DESC, true );
			}
		} elseif ( is_author() ) {
			$uid = (int) get_query_var( 'author' );
			if ( ! $uid ) {
				$au  = get_queried_object();
				$uid = $au && isset( $au->ID ) ? (int) $au->ID : 0;
			}
			if ( $uid ) {
				$out['title']       = (string) get_user_meta( $uid, self::META_TITLE, true );
				$out['description'] = (string) get_user_meta( $uid, self::META_DESC, true );
			}
		}
		return $out;
	}
}
