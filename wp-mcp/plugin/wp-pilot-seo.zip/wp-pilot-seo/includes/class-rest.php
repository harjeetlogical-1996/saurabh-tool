<?php
/**
 * REST API so the wptaskify MCP server (AI assistant) can read & write all SEO
 * fields, manage FAQ items, and fetch the SEO score.
 *
 * Namespace: wppseo/v1
 *   GET  /seo?post=ID            -> all SEO fields + score
 *   POST /seo                    -> {post, fields:{...}} update fields
 *   GET  /score?post=ID          -> SEO score + checks
 *   POST /faq                    -> {post, items:[{q,a}]} set FAQ
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WPPSEO_REST {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'rest_api_init', array( $this, 'routes' ) );
	}

	public function perm() {
		return current_user_can( 'edit_posts' );
	}

	public function routes() {
		$ns = 'wppseo/v1';

		register_rest_route( $ns, '/seo', array(
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'get_seo' ),
				'permission_callback' => array( $this, 'perm' ),
				'args'                => array( 'post' => array( 'required' => true, 'sanitize_callback' => 'absint' ) ),
			),
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'set_seo' ),
				'permission_callback' => array( $this, 'perm' ),
			),
		) );

		register_rest_route( $ns, '/score', array(
			'methods'             => 'GET',
			'callback'            => array( $this, 'get_score' ),
			'permission_callback' => array( $this, 'perm' ),
			'args'                => array( 'post' => array( 'required' => true, 'sanitize_callback' => 'absint' ) ),
		) );

		register_rest_route( $ns, '/faq', array(
			'methods'             => 'POST',
			'callback'            => array( $this, 'set_faq' ),
			'permission_callback' => array( $this, 'perm' ),
		) );

		register_rest_route( $ns, '/info', array(
			'methods'             => 'GET',
			'callback'            => array( $this, 'info' ),
			'permission_callback' => array( $this, 'perm' ),
		) );

		// Site-wide SEO settings (Knowledge Graph identity, homepage SEO, default
		// OG image). More sensitive than per-post, so require manage_options.
		register_rest_route( $ns, '/settings', array(
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'get_settings' ),
				'permission_callback' => array( $this, 'perm_admin' ),
			),
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'set_settings' ),
				'permission_callback' => array( $this, 'perm_admin' ),
			),
		) );

		// Archive SEO: term (category/tag/tax) + author archive meta title/desc.
		register_rest_route( $ns, '/term-seo', array(
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'get_term_seo' ),
				'permission_callback' => array( $this, 'perm' ),
				'args'                => array( 'term' => array( 'required' => true, 'sanitize_callback' => 'absint' ) ),
			),
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'set_term_seo' ),
				'permission_callback' => array( $this, 'perm_admin' ),
			),
		) );
		register_rest_route( $ns, '/author-seo', array(
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'get_author_seo' ),
				'permission_callback' => array( $this, 'perm' ),
				'args'                => array( 'user' => array( 'required' => true, 'sanitize_callback' => 'absint' ) ),
			),
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'set_author_seo' ),
				'permission_callback' => array( $this, 'perm_admin' ),
			),
		) );
	}

	// ---- Archive SEO (term + author) -----------------------------------

	public function get_term_seo( $req ) {
		$term_id = absint( $req->get_param( 'term' ) );
		if ( ! $term_id || ! term_exists( $term_id ) ) {
			return new WP_Error( 'no_term', 'Term not found', array( 'status' => 404 ) );
		}
		return rest_ensure_response( array(
			'term'        => $term_id,
			'title'       => (string) get_term_meta( $term_id, WPPSEO_Archive_SEO::META_TITLE, true ),
			'description' => (string) get_term_meta( $term_id, WPPSEO_Archive_SEO::META_DESC, true ),
		) );
	}

	public function set_term_seo( $req ) {
		$body    = (array) $req->get_json_params();
		$term_id = absint( isset( $body['term'] ) ? $body['term'] : 0 );
		if ( ! $term_id || ! term_exists( $term_id ) ) {
			return new WP_Error( 'no_term', 'Term not found', array( 'status' => 404 ) );
		}
		if ( array_key_exists( 'title', $body ) ) {
			update_term_meta( $term_id, WPPSEO_Archive_SEO::META_TITLE, sanitize_text_field( (string) $body['title'] ) );
		}
		if ( array_key_exists( 'description', $body ) ) {
			update_term_meta( $term_id, WPPSEO_Archive_SEO::META_DESC, sanitize_textarea_field( (string) $body['description'] ) );
		}
		return $this->get_term_seo( $req );
	}

	public function get_author_seo( $req ) {
		$uid = absint( $req->get_param( 'user' ) );
		if ( ! $uid || ! get_userdata( $uid ) ) {
			return new WP_Error( 'no_user', 'User not found', array( 'status' => 404 ) );
		}
		return rest_ensure_response( array(
			'user'        => $uid,
			'title'       => (string) get_user_meta( $uid, WPPSEO_Archive_SEO::META_TITLE, true ),
			'description' => (string) get_user_meta( $uid, WPPSEO_Archive_SEO::META_DESC, true ),
		) );
	}

	public function set_author_seo( $req ) {
		$body = (array) $req->get_json_params();
		$uid  = absint( isset( $body['user'] ) ? $body['user'] : 0 );
		if ( ! $uid || ! get_userdata( $uid ) ) {
			return new WP_Error( 'no_user', 'User not found', array( 'status' => 404 ) );
		}
		if ( array_key_exists( 'title', $body ) ) {
			update_user_meta( $uid, WPPSEO_Archive_SEO::META_TITLE, sanitize_text_field( (string) $body['title'] ) );
		}
		if ( array_key_exists( 'description', $body ) ) {
			update_user_meta( $uid, WPPSEO_Archive_SEO::META_DESC, sanitize_textarea_field( (string) $body['description'] ) );
		}
		return $this->get_author_seo( $req );
	}

	/** Site-wide settings need admin (option-level) capability. */
	public function perm_admin() {
		return current_user_can( 'manage_options' );
	}

	/** GET the site-wide SEO settings. */
	public function get_settings() {
		if ( ! class_exists( 'WPPSEO_Settings' ) ) {
			return new WP_Error( 'no_settings', 'Settings unavailable', array( 'status' => 500 ) );
		}
		return rest_ensure_response( WPPSEO_Settings::all() );
	}

	/** POST to update the site-wide SEO settings (sanitized by WPPSEO_Settings). */
	public function set_settings( $req ) {
		if ( ! class_exists( 'WPPSEO_Settings' ) ) {
			return new WP_Error( 'no_settings', 'Settings unavailable', array( 'status' => 500 ) );
		}
		$body    = $req->get_json_params();
		$body    = is_array( $body ) ? $body : array();
		// Merge onto current so a partial update only changes the given keys.
		$current = WPPSEO_Settings::all();
		$merged  = array_merge( $current, $body );
		$clean   = WPPSEO_Settings::sanitize( $merged );
		update_option( WPPSEO_Settings::OPTION, $clean );
		return rest_ensure_response( array( 'saved' => true, 'settings' => $clean ) );
	}

	/** Capability discovery for the MCP server. */
	public function info() {
		return array(
			'plugin'  => 'wp-pilot-seo',
			'version' => WPPSEO_VERSION,
			'fields'  => array_keys( wppseo_meta_keys() ),
			'sitemap' => home_url( '/' . WPPSEO_Sitemap::SLUG ),
		);
	}

	public function get_seo( $request ) {
		$post_id = $request->get_param( 'post' );
		if ( ! get_post( $post_id ) ) {
			return new WP_Error( 'not_found', 'Post not found', array( 'status' => 404 ) );
		}
		$out = array( 'post' => $post_id );
		foreach ( wppseo_meta_keys() as $key => $meta_key ) {
			$out[ $key ] = wppseo_get( $post_id, $key );
		}
		$out['score'] = WPPSEO_Score::analyze( $post_id );
		return rest_ensure_response( $out );
	}

	public function set_seo( $request ) {
		$body    = $request->get_json_params();
		$post_id = isset( $body['post'] ) ? absint( $body['post'] ) : 0;
		$fields  = isset( $body['fields'] ) && is_array( $body['fields'] ) ? $body['fields'] : array();
		if ( ! $post_id || ! get_post( $post_id ) ) {
			return new WP_Error( 'bad_post', 'Valid post id required', array( 'status' => 400 ) );
		}
		// IDOR guard: caller must be able to edit THIS specific post, not just have the
		// global edit_posts capability (which would let an Author edit others' SEO).
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return new WP_Error( 'forbidden', 'You cannot edit this post.', array( 'status' => 403 ) );
		}

		$allowed = array(
			'title'       => 'sanitize_text_field',
			'description' => 'sanitize_textarea_field',
			'focus_kw'    => 'sanitize_text_field',
			'keywords'    => 'sanitize_text_field',
			'og_title'    => 'sanitize_text_field',
			'og_desc'     => 'sanitize_textarea_field',
			'og_image'    => 'esc_url_raw',
			'canonical'   => 'esc_url_raw',
			'schema_type' => 'sanitize_text_field',
			'noindex'     => 'sanitize_text_field',
			// AEO / GEO fields (AI can read+write these).
			'quick_answer'  => 'sanitize_textarea_field',
			'key_takeaways' => 'sanitize_textarea_field',
			'reviewed_by'   => 'sanitize_text_field',
			'last_reviewed' => 'sanitize_text_field',
			'speakable'     => 'sanitize_text_field',
			'in_language'   => 'sanitize_text_field',
		);
		$updated = array();
		foreach ( $fields as $key => $val ) {
			if ( ! isset( $allowed[ $key ] ) ) {
				continue;
			}
			$clean = call_user_func( $allowed[ $key ], $val );
			update_post_meta( $post_id, wppseo_key( $key ), $clean );
			$updated[ $key ] = $clean;
		}
		return rest_ensure_response( array(
			'post'    => $post_id,
			'updated' => $updated,
			'score'   => WPPSEO_Score::analyze( $post_id ),
		) );
	}

	public function get_score( $request ) {
		$post_id = $request->get_param( 'post' );
		if ( ! get_post( $post_id ) ) {
			return new WP_Error( 'not_found', 'Post not found', array( 'status' => 404 ) );
		}
		return rest_ensure_response( WPPSEO_Score::analyze( $post_id ) );
	}

	public function set_faq( $request ) {
		$body    = $request->get_json_params();
		$post_id = isset( $body['post'] ) ? absint( $body['post'] ) : 0;
		$items   = isset( $body['items'] ) && is_array( $body['items'] ) ? $body['items'] : array();
		if ( ! $post_id || ! get_post( $post_id ) ) {
			return new WP_Error( 'bad_post', 'Valid post id required', array( 'status' => 400 ) );
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return new WP_Error( 'forbidden', 'You cannot edit this post.', array( 'status' => 403 ) );
		}
		// Cap FAQ item count + answer length (prevent bloat / DoS - LOW finding #16).
		if ( count( $items ) > 50 ) {
			$items = array_slice( $items, 0, 50 );
		}
		$clean = array();
		foreach ( $items as $it ) {
			if ( empty( $it['q'] ) || empty( $it['a'] ) ) {
				continue;
			}
			$clean[] = array(
				'q' => sanitize_text_field( $it['q'] ),
				'a' => wp_kses_post( $it['a'] ),
			);
		}
		update_post_meta( $post_id, wppseo_key( 'faq' ), wp_json_encode( $clean ) );
		return rest_ensure_response( array( 'post' => $post_id, 'faq_count' => count( $clean ) ) );
	}
}
