<?php
/**
 * Site-wide SEO settings (Batch 1): Knowledge Graph identity (Organization or
 * Person, logo, social profiles / sameAs, topics / knowsAbout), homepage / blog
 * SEO overrides, and a site-wide default Open Graph image. Stored as a single
 * option array `wppseo_settings` and read by the schema + frontend classes.
 *
 * These settings are also fully readable/writable by the AI (via REST), so
 * "connect to AI" can configure a site's Knowledge Graph in one step.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WPPSEO_Settings {

	const OPTION = 'wppseo_settings';

	/** Default shape - every key present so callers never juggle isset(). */
	public static function defaults() {
		return array(
			'entity_type'   => 'Organization', // 'Organization' | 'Person'
			'entity_name'   => '',             // falls back to site name if empty
			'logo_id'       => 0,              // attachment ID (Organization logo / Person image)
			'same_as'       => '',             // newline-separated social profile URLs
			'knows_about'   => '',             // newline-separated topics
			'home_title'    => '',             // homepage SEO title override
			'home_desc'     => '',             // homepage meta description override
			'default_og_id' => 0,              // site-wide default OG image attachment ID
			// SEO output toggles. Let users turn wptaskify's front-end SEO on/off -
			// essential when another SEO plugin (Yoast/Rank Math) is active, so tags
			// aren't duplicated. All ON by default. '1' = on, '' = off.
			'seo_enabled'    => '1',           // master switch for all front-end SEO output
			'output_meta'    => '1',           // <title>, meta description, canonical, robots, keywords
			'output_og'      => '1',           // Open Graph + Twitter card tags
			'output_schema'  => '1',           // JSON-LD structured data
			'output_aeo'     => '1',           // quick-answer / key-takeaways block
			// Analytics & webmaster verification (site-wide head tags).
			'ga4_id'         => '',            // GA4 Measurement ID, e.g. G-XXXXXXX
			'gsc_verify'     => '',            // Google Search Console verification token
			'bing_verify'    => '',            // Bing Webmaster verification token
			'head_code'      => '',            // extra raw <head> code (verification/pixels)
		);
	}

	/** Is a given SEO output feature enabled? Master switch gates everything. */
	public static function output_on( $feature ) {
		$all = self::all();
		if ( empty( $all['seo_enabled'] ) ) {
			return false; // master off = everything off
		}
		$key = 'output_' . $feature;
		return ! empty( $all[ $key ] );
	}

	/** Read the merged settings (defaults + saved). */
	public static function all() {
		$saved = get_option( self::OPTION, array() );
		if ( ! is_array( $saved ) ) {
			$saved = array();
		}
		return array_merge( self::defaults(), $saved );
	}

	/** Read one setting. */
	public static function get( $key, $fallback = '' ) {
		$all = self::all();
		return array_key_exists( $key, $all ) ? $all[ $key ] : $fallback;
	}

	/** sameAs / knowsAbout are stored as text; return them as a clean array. */
	public static function lines( $key ) {
		$raw = (string) self::get( $key, '' );
		$out = array();
		foreach ( preg_split( '/[\r\n]+/', $raw ) as $line ) {
			$line = trim( $line );
			if ( $line !== '' ) {
				$out[] = $line;
			}
		}
		return $out;
	}

	/**
	 * Sanitize the full settings array before saving. Registered as the
	 * sanitize_callback so option writes (form OR update_option) are always clean.
	 */
	public static function sanitize( $input ) {
		$d   = self::defaults();
		$in  = is_array( $input ) ? $input : array();
		$out = array();

		$type = isset( $in['entity_type'] ) ? $in['entity_type'] : $d['entity_type'];
		$out['entity_type'] = ( $type === 'Person' ) ? 'Person' : 'Organization';

		$out['entity_name'] = isset( $in['entity_name'] ) ? sanitize_text_field( $in['entity_name'] ) : '';
		$out['logo_id']     = isset( $in['logo_id'] ) ? absint( $in['logo_id'] ) : 0;

		// sameAs: keep only valid URLs, one per line.
		$out['same_as'] = self::sanitize_url_lines( isset( $in['same_as'] ) ? $in['same_as'] : '' );

		// knowsAbout: free-text topics, one per line.
		$out['knows_about'] = self::sanitize_text_lines( isset( $in['knows_about'] ) ? $in['knows_about'] : '' );

		$out['home_title']    = isset( $in['home_title'] ) ? sanitize_text_field( $in['home_title'] ) : '';
		$out['home_desc']     = isset( $in['home_desc'] ) ? sanitize_textarea_field( $in['home_desc'] ) : '';
		$out['default_og_id'] = isset( $in['default_og_id'] ) ? absint( $in['default_og_id'] ) : 0;

		// SEO output toggles. The settings form always renders these checkboxes, and
		// an UNCHECKED checkbox sends nothing - so "present & truthy" = on, absent =
		// off. A hidden marker field (_seo_form) tells us the toggle form was the
		// source; for non-form writes that omit the marker we preserve current
		// values so a partial programmatic update doesn't silently disable SEO.
		$from_form = ! empty( $in['_seo_form'] );
		$current   = self::all();
		foreach ( array( 'seo_enabled', 'output_meta', 'output_og', 'output_schema', 'output_aeo' ) as $tk ) {
			if ( $from_form ) {
				$out[ $tk ] = empty( $in[ $tk ] ) ? '' : '1';
			} elseif ( array_key_exists( $tk, $in ) ) {
				$out[ $tk ] = empty( $in[ $tk ] ) ? '' : '1';
			} else {
				$out[ $tk ] = ! empty( $current[ $tk ] ) ? '1' : '';
			}
		}

		// Analytics & webmaster verification.
		// GA4 ID: keep only a valid G-XXXX shape (letters/digits) - never trust raw.
		$ga = isset( $in['ga4_id'] ) ? strtoupper( trim( sanitize_text_field( $in['ga4_id'] ) ) ) : '';
		$out['ga4_id'] = preg_match( '/^G-[A-Z0-9]{4,20}$/', $ga ) ? $ga : '';
		// Verification tokens are opaque strings - users often paste the whole meta
		// tag; extract just the content="..." token if they did.
		$out['gsc_verify']  = self::extract_verify_token( isset( $in['gsc_verify'] ) ? $in['gsc_verify'] : '' );
		$out['bing_verify'] = self::extract_verify_token( isset( $in['bing_verify'] ) ? $in['bing_verify'] : '' );
		// Raw head code: admin-only, but still strip anything that isn't a safe
		// verification/analytics tag set. Allow <meta>, <script>, <link>, <noscript>.
		$out['head_code'] = isset( $in['head_code'] ) ? self::sanitize_head_code( $in['head_code'] ) : '';

		return $out;
	}

	/** Pull a bare verification token out of a full <meta ... content="TOKEN"> if
	 * the user pasted the whole tag; otherwise sanitize the token as-is. */
	private static function extract_verify_token( $raw ) {
		$raw = trim( (string) $raw );
		if ( $raw === '' ) {
			return '';
		}
		if ( preg_match( '/content=["\']([^"\']+)["\']/i', $raw, $m ) ) {
			$raw = $m[1];
		}
		// Verification tokens are alphanumeric + a few symbols.
		$raw = preg_replace( '/[^A-Za-z0-9_\-\.]/', '', $raw );
		return substr( (string) $raw, 0, 200 );
	}

	/** Restrict raw head code to verification/analytics-style tags only. */
	private static function sanitize_head_code( $raw ) {
		$allowed = array(
			'meta'     => array( 'name' => true, 'content' => true, 'property' => true, 'charset' => true, 'http-equiv' => true ),
			'link'     => array( 'rel' => true, 'href' => true, 'type' => true, 'sizes' => true, 'crossorigin' => true ),
			'script'   => array( 'src' => true, 'async' => true, 'defer' => true, 'type' => true, 'id' => true, 'crossorigin' => true ),
			'noscript' => array(),
		);
		return wp_kses( (string) $raw, $allowed );
	}

	private static function sanitize_url_lines( $raw ) {
		$out = array();
		foreach ( preg_split( '/[\r\n]+/', (string) $raw ) as $line ) {
			$line = trim( $line );
			if ( $line === '' ) {
				continue;
			}
			$url = esc_url_raw( $line );
			if ( $url ) {
				$out[] = $url;
			}
		}
		return implode( "\n", $out );
	}

	private static function sanitize_text_lines( $raw ) {
		$out = array();
		foreach ( preg_split( '/[\r\n]+/', (string) $raw ) as $line ) {
			$line = sanitize_text_field( trim( $line ) );
			if ( $line !== '' ) {
				$out[] = $line;
			}
		}
		return implode( "\n", $out );
	}

	/** Register the option so both the form and the AI/REST layer share one schema. */
	public static function register() {
		register_setting(
			'wppseo_settings_group',
			self::OPTION,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( __CLASS__, 'sanitize' ),
				'default'           => self::defaults(),
			)
		);
	}
}

add_action( 'admin_init', array( 'WPPSEO_Settings', 'register' ) );
