<?php
/**
 * Frontend <head> output: title, meta description, canonical, robots,
 * Open Graph and Twitter Card tags.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WPPSEO_Frontend {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		// Let us control the document title.
		add_filter( 'pre_get_document_title', array( $this, 'doc_title' ), 20 );
		add_theme_support( 'title-tag' );
		add_action( 'wp_head', array( $this, 'output' ), 1 );
		// Analytics + webmaster verification tags (independent of the SEO toggle).
		add_action( 'wp_head', array( $this, 'analytics_head' ), 2 );
		// AEO: render the quick-answer / key-takeaways block at the top of content.
		add_filter( 'the_content', array( $this, 'aeo_block' ), 8 );
		// Remove core's default robots so ours wins when set.
	}

	/**
	 * Output analytics + search-engine verification tags in <head>. Kept separate
	 * from the SEO meta toggle: a user may disable SEO meta (using another plugin)
	 * but still want their GA/verification here. Nothing is printed for empty
	 * fields, and admin previews are skipped to keep pageviews honest.
	 */
	public function analytics_head() {
		if ( ! class_exists( 'WPPSEO_Settings' ) ) {
			return;
		}
		$s = WPPSEO_Settings::all();

		// Search Console / Bing verification meta tags.
		if ( ! empty( $s['gsc_verify'] ) ) {
			printf( "<meta name=\"google-site-verification\" content=\"%s\">\n", esc_attr( $s['gsc_verify'] ) );
		}
		if ( ! empty( $s['bing_verify'] ) ) {
			printf( "<meta name=\"msvalidate.01\" content=\"%s\">\n", esc_attr( $s['bing_verify'] ) );
		}

		// GA4: build the gtag snippet from the ID (don't run analytics for logged-in
		// admins/editors, so internal visits don't skew the numbers).
		if ( ! empty( $s['ga4_id'] ) && ! current_user_can( 'edit_posts' ) ) {
			$id = esc_js( $s['ga4_id'] );
			echo '<script async src="https://www.googletagmanager.com/gtag/js?id=' . esc_attr( rawurlencode( $s['ga4_id'] ) ) . '"></script>' . "\n";
			echo "<script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag('js',new Date());gtag('config','" . $id . "');</script>\n";
		}

		// Extra raw head code (already wp_kses-sanitized on save).
		if ( ! empty( $s['head_code'] ) ) {
			echo $s['head_code'] . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- sanitized via wp_kses on save
		}
	}

	/**
	 * Prepend an answer-engine-friendly block (quick answer + key takeaways) to the
	 * post content. The `.wppseo-quick-answer` element is also the speakable target.
	 * Only on the main singular query, only when the fields are set.
	 */
	public function aeo_block( $content ) {
		if ( ! is_singular() || ! in_the_loop() || ! is_main_query() ) {
			return $content;
		}
		if ( class_exists( 'WPPSEO_Settings' ) && ! WPPSEO_Settings::output_on( 'aeo' ) ) {
			return $content; // AEO output toggled off
		}
		$post_id = get_the_ID();
		if ( ! $post_id ) {
			return $content;
		}
		$quick    = trim( (string) wppseo_get( $post_id, 'quick_answer' ) );
		$takeaway = trim( (string) wppseo_get( $post_id, 'key_takeaways' ) );
		if ( '' === $quick && '' === $takeaway ) {
			return $content;
		}
		$html = '';
		if ( $quick !== '' ) {
			$html .= '<div class="wppseo-quick-answer">' . esc_html( $quick ) . '</div>';
		}
		if ( $takeaway !== '' ) {
			$items = array_filter( array_map( 'trim', preg_split( '/[\r\n]+/', $takeaway ) ) );
			if ( $items ) {
				$html .= '<div class="wppseo-key-takeaways"><strong>' .
					esc_html__( 'Key takeaways', 'wp-pilot-seo' ) . '</strong><ul>';
				foreach ( $items as $it ) {
					$html .= '<li>' . esc_html( $it ) . '</li>';
				}
				$html .= '</ul></div>';
			}
		}
		return $html . $content;
	}

	/** Homepage SEO override from site settings (front page or posts page). */
	private function home_override( $key ) {
		if ( ! class_exists( 'WPPSEO_Settings' ) ) {
			return '';
		}
		if ( is_front_page() || is_home() ) {
			return (string) WPPSEO_Settings::get( $key, '' );
		}
		return '';
	}

	/** Archive SEO override (term / author). $key is 'title' or 'description'. */
	private function archive_override( $key ) {
		if ( ! class_exists( 'WPPSEO_Archive_SEO' ) ) {
			return '';
		}
		$a = WPPSEO_Archive_SEO::current();
		return isset( $a[ $key ] ) ? (string) $a[ $key ] : '';
	}

	private function resolved_title( $post_id ) {
		$t = $post_id ? wppseo_get( $post_id, 'title' ) : '';
		if ( $t ) {
			return $t;
		}
		$home_t = $this->home_override( 'home_title' );
		if ( $home_t ) {
			return $home_t;
		}
		$arch_t = $this->archive_override( 'title' );
		if ( $arch_t ) {
			return $arch_t;
		}
		if ( is_singular() ) {
			return get_the_title( $post_id ) . ' - ' . get_bloginfo( 'name' );
		}
		return get_bloginfo( 'name' );
	}

	private function resolved_desc( $post_id ) {
		$d = $post_id ? wppseo_get( $post_id, 'description' ) : '';
		if ( $d ) {
			return $d;
		}
		$home_d = $this->home_override( 'home_desc' );
		if ( $home_d ) {
			return $home_d;
		}
		$arch_d = $this->archive_override( 'description' );
		if ( $arch_d ) {
			return $arch_d;
		}
		if ( is_singular() && $post_id ) {
			$excerpt = get_the_excerpt( $post_id );
			if ( $excerpt ) {
				return wp_trim_words( wp_strip_all_tags( $excerpt ), 30 );
			}
		}
		return get_bloginfo( 'description' );
	}

	public function doc_title( $title ) {
		// Respect the meta toggle: if SEO/meta output is off, don't touch the title
		// (let the theme or another SEO plugin control it).
		if ( class_exists( 'WPPSEO_Settings' ) && ! WPPSEO_Settings::output_on( 'meta' ) ) {
			return $title;
		}
		$post_id = is_singular() ? get_queried_object_id() : 0;
		$custom  = $post_id ? wppseo_get( $post_id, 'title' ) : '';
		if ( $custom ) {
			return $custom;
		}
		$home_t = $this->home_override( 'home_title' );
		if ( $home_t ) {
			return $home_t;
		}
		$arch_t = $this->archive_override( 'title' );
		return $arch_t ? $arch_t : $title;
	}

	public function output() {
		// Master + per-feature toggles: let users turn wptaskify's front-end SEO
		// off (e.g. when running Yoast/Rank Math) so tags aren't duplicated.
		$has_settings = class_exists( 'WPPSEO_Settings' );
		if ( $has_settings && ! WPPSEO_Settings::get( 'seo_enabled', '1' ) ) {
			return; // master switch off -> emit nothing
		}
		$do_meta = ! $has_settings || WPPSEO_Settings::output_on( 'meta' );
		$do_og   = ! $has_settings || WPPSEO_Settings::output_on( 'og' );

		$post_id = is_singular() ? get_queried_object_id() : 0;
		$title   = $this->resolved_title( $post_id );
		$desc    = $this->resolved_desc( $post_id );
		if ( is_singular() ) {
			$url = get_permalink( $post_id );
		} else {
			$req = isset( $GLOBALS['wp']->request ) ? $GLOBALS['wp']->request : '';
			$url = home_url( $req ? '/' . $req : '/' );
		}

		echo "\n<!-- wptaskify -->\n";

		if ( $do_meta ) :
		// Meta description.
		if ( $desc ) {
			printf( "<meta name=\"description\" content=\"%s\">\n", esc_attr( $desc ) );
		}

		// Robots (noindex).
		$noindex = $post_id ? wppseo_get( $post_id, 'noindex' ) : '';
		$robots  = $noindex ? 'noindex, follow' : 'index, follow, max-image-preview:large';
		printf( "<meta name=\"robots\" content=\"%s\">\n", esc_attr( $robots ) );

		// Canonical.
		$canon = $post_id ? wppseo_get( $post_id, 'canonical' ) : '';
		if ( ! $canon ) {
			$canon = $url;
		}
		printf( "<link rel=\"canonical\" href=\"%s\">\n", esc_url( $canon ) );

		// Keywords (optional, low SEO weight but user asked for it).
		$kw = $post_id ? wppseo_get( $post_id, 'keywords' ) : '';
		$focus = $post_id ? wppseo_get( $post_id, 'focus_kw' ) : '';
		$kw_all = trim( $focus . ( $focus && $kw ? ', ' : '' ) . $kw );
		if ( $kw_all ) {
			printf( "<meta name=\"keywords\" content=\"%s\">\n", esc_attr( $kw_all ) );
		}
		endif; // $do_meta

		if ( $do_og ) :
		// Open Graph.
		$og_title = $post_id ? wppseo_get( $post_id, 'og_title' ) : '';
		$og_desc  = $post_id ? wppseo_get( $post_id, 'og_desc' ) : '';
		// OG image fallback chain: per-post og_image -> featured image -> site default.
		$og_img   = $post_id ? wppseo_get( $post_id, 'og_image' ) : '';
		if ( ! $og_img && $post_id && has_post_thumbnail( $post_id ) ) {
			$og_img = get_the_post_thumbnail_url( $post_id, 'large' );
		}
		if ( ! $og_img && class_exists( 'WPPSEO_Settings' ) ) {
			$default_id = (int) WPPSEO_Settings::get( 'default_og_id', 0 );
			if ( $default_id ) {
				$def = wp_get_attachment_image_url( $default_id, 'large' );
				if ( $def ) {
					$og_img = $def;
				}
			}
		}
		$og_title = $og_title ? $og_title : $title;
		$og_desc  = $og_desc ? $og_desc : $desc;

		printf( "<meta property=\"og:locale\" content=\"%s\">\n", esc_attr( get_locale() ) );
		printf( "<meta property=\"og:type\" content=\"%s\">\n", is_singular() ? 'article' : 'website' );
		printf( "<meta property=\"og:title\" content=\"%s\">\n", esc_attr( $og_title ) );
		if ( $og_desc ) {
			printf( "<meta property=\"og:description\" content=\"%s\">\n", esc_attr( $og_desc ) );
		}
		printf( "<meta property=\"og:url\" content=\"%s\">\n", esc_url( $url ) );
		printf( "<meta property=\"og:site_name\" content=\"%s\">\n", esc_attr( get_bloginfo( 'name' ) ) );
		if ( $og_img ) {
			printf( "<meta property=\"og:image\" content=\"%s\">\n", esc_url( $og_img ) );
		}

		// Twitter.
		printf( "<meta name=\"twitter:card\" content=\"%s\">\n", $og_img ? 'summary_large_image' : 'summary' );
		printf( "<meta name=\"twitter:title\" content=\"%s\">\n", esc_attr( $og_title ) );
		if ( $og_desc ) {
			printf( "<meta name=\"twitter:description\" content=\"%s\">\n", esc_attr( $og_desc ) );
		}
		if ( $og_img ) {
			printf( "<meta name=\"twitter:image\" content=\"%s\">\n", esc_url( $og_img ) );
		}
		endif; // $do_og

		// Minimal styling for the AEO quick-answer / key-takeaways block, only when
		// this singular post actually has those fields set.
		if ( $post_id && ( wppseo_get( $post_id, 'quick_answer' ) || wppseo_get( $post_id, 'key_takeaways' ) ) ) {
			echo '<style id="wppseo-aeo-css">.wppseo-quick-answer{font-size:1.05em;line-height:1.6;padding:14px 18px;margin:0 0 18px;border-left:4px solid #2563eb;background:#f5f8ff;border-radius:6px}.wppseo-key-takeaways{padding:12px 18px;margin:0 0 20px;background:#f7f7f8;border-radius:6px}.wppseo-key-takeaways ul{margin:8px 0 0;padding-left:20px}.wppseo-key-takeaways li{margin:4px 0}</style>' . "\n";
		}

		echo "<!-- /wptaskify -->\n";
	}
}
