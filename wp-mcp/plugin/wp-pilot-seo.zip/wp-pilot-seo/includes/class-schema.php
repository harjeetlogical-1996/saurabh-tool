<?php
/**
 * JSON-LD structured data output (@graph): Organization, WebSite,
 * BreadcrumbList, and per-post Article/Product/FAQPage/HowTo.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WPPSEO_Schema {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'wp_head', array( $this, 'output' ), 5 );
	}

	public function output() {
		// Respect the schema output toggle (off when another SEO plugin handles it).
		if ( class_exists( 'WPPSEO_Settings' ) && ! WPPSEO_Settings::output_on( 'schema' ) ) {
			return;
		}
		$graph = array();
		$home  = home_url( '/' );
		$site  = get_bloginfo( 'name' );

		// Site-wide identity from settings (Batch 1). Falls back to sensible
		// defaults so a site that never opened the settings page still gets valid
		// schema.
		$s         = class_exists( 'WPPSEO_Settings' ) ? WPPSEO_Settings::all() : array();
		$entity    = ( isset( $s['entity_type'] ) && $s['entity_type'] === 'Person' ) ? 'Person' : 'Organization';
		$entity_nm = ! empty( $s['entity_name'] ) ? $s['entity_name'] : $site;
		$same_as   = class_exists( 'WPPSEO_Settings' ) ? WPPSEO_Settings::lines( 'same_as' ) : array();
		$knows     = class_exists( 'WPPSEO_Settings' ) ? WPPSEO_Settings::lines( 'knows_about' ) : array();

		// Organization OR Person (Knowledge Graph publisher entity).
		$org = array(
			'@type' => $entity,
			'@id'   => $home . '#organization',
			'name'  => $entity_nm,
			'url'   => $home,
		);

		// Logo: configured logo first, else the theme's custom logo.
		$logo = '';
		if ( ! empty( $s['logo_id'] ) ) {
			$logo = wp_get_attachment_image_url( (int) $s['logo_id'], 'full' );
		}
		if ( ! $logo ) {
			$theme_logo = get_theme_mod( 'custom_logo' );
			if ( $theme_logo ) {
				$logo = wp_get_attachment_image_url( $theme_logo, 'full' );
			}
		}
		if ( $logo ) {
			// schema.org: Organization uses `logo`, Person uses `image`.
			if ( $entity === 'Person' ) {
				$org['image'] = $logo;
			} else {
				$org['logo'] = $logo;
			}
		}
		if ( ! empty( $same_as ) ) {
			$org['sameAs'] = array_values( $same_as );
		}
		if ( ! empty( $knows ) ) {
			$org['knowsAbout'] = array_values( $knows );
		}
		$graph[] = $org;

		// WebSite.
		$graph[] = array(
			'@type'     => 'WebSite',
			'@id'       => $home . '#website',
			'url'       => $home,
			'name'      => $site,
			'publisher' => array( '@id' => $home . '#organization' ),
		);

		if ( is_singular() ) {
			$post_id = get_queried_object_id();
			$graph   = array_merge( $graph, $this->singular_graph( $post_id, $home ) );
		}

		$data = array(
			'@context' => 'https://schema.org',
			'@graph'   => $graph,
		);

		echo "<script type=\"application/ld+json\">" .
			wp_json_encode( $data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) .
			"</script>\n";
	}

	private function singular_graph( $post_id, $home ) {
		$out  = array();
		$url  = get_permalink( $post_id );
		$type = wppseo_get( $post_id, 'schema_type', 'Article' );

		// Breadcrumb.
		$crumbs = array(
			array( '@type' => 'ListItem', 'position' => 1, 'name' => 'Home', 'item' => $home ),
			array( '@type' => 'ListItem', 'position' => 2, 'name' => get_the_title( $post_id ), 'item' => $url ),
		);
		$out[] = array(
			'@type'           => 'BreadcrumbList',
			'@id'             => $url . '#breadcrumb',
			'itemListElement' => $crumbs,
		);

		// Main entity (Article-like by default).
		$author_id = get_post_field( 'post_author', $post_id );
		$main = array(
			'@type'         => $type,
			'@id'           => $url . '#main',
			'headline'      => get_the_title( $post_id ),
			'url'           => $url,
			'datePublished' => get_the_date( 'c', $post_id ),
			'dateModified'  => get_the_modified_date( 'c', $post_id ),
			'author'        => array( '@type' => 'Person', 'name' => get_the_author_meta( 'display_name', $author_id ) ),
			'publisher'     => array( '@id' => $home . '#organization' ),
			'mainEntityOfPage' => array( '@type' => 'WebPage', '@id' => $url ),
		);
		$desc = wppseo_get( $post_id, 'description' );
		if ( $desc ) {
			$main['description'] = $desc;
		}
		if ( has_post_thumbnail( $post_id ) ) {
			$main['image'] = get_the_post_thumbnail_url( $post_id, 'large' );
		}

		// AEO / GEO enrichment (our edge). All optional - only added when set.
		$in_lang = trim( (string) wppseo_get( $post_id, 'in_language' ) );
		if ( '' === $in_lang ) {
			$in_lang = str_replace( '_', '-', get_locale() );
		}
		if ( $in_lang ) {
			$main['inLanguage'] = $in_lang;
		}
		// Reviewer (E-E-A-T): reviewedBy + a review date distinct from dateModified.
		$reviewer = trim( (string) wppseo_get( $post_id, 'reviewed_by' ) );
		if ( $reviewer ) {
			$main['reviewedBy'] = array( '@type' => 'Person', 'name' => $reviewer );
		}
		$reviewed = trim( (string) wppseo_get( $post_id, 'last_reviewed' ) );
		if ( $reviewed ) {
			$main['lastReviewed'] = $reviewed;
		}
		// key_takeaways -> abstract (a machine-readable TL;DR).
		$takeaways = trim( (string) wppseo_get( $post_id, 'key_takeaways' ) );
		if ( $takeaways ) {
			$lines = array_filter( array_map( 'trim', preg_split( '/[\r\n]+/', $takeaways ) ) );
			if ( $lines ) {
				$main['abstract'] = implode( ' ', $lines );
			}
		}
		// speakable: mark the headline + quick-answer region as voice-readable.
		if ( wppseo_get( $post_id, 'speakable' ) === '1' ) {
			$main['speakable'] = array(
				'@type'       => 'SpeakableSpecification',
				'cssSelector' => array( 'h1', '.wppseo-quick-answer' ),
			);
		}
		// FAQPage handled separately below; if type is FAQPage, attach questions.
		if ( 'FAQPage' === $type ) {
			$faq = $this->faq_items( $post_id );
			if ( $faq ) {
				$main['mainEntity'] = $faq;
			}
		}
		$out[] = $main;

		// Always also emit FAQ if items exist (even if main type isn't FAQPage).
		if ( 'FAQPage' !== $type ) {
			$faq = $this->faq_items( $post_id );
			if ( $faq ) {
				$out[] = array(
					'@type'      => 'FAQPage',
					'@id'        => $url . '#faq',
					'mainEntity' => $faq,
				);
			}
		}

		return $out;
	}

	/**
	 * FAQ items stored as JSON in the _wppseo_faq meta:
	 * [{"q":"Question?","a":"Answer."}, ...]
	 */
	private function faq_items( $post_id ) {
		$raw = wppseo_get( $post_id, 'faq' );
		if ( ! $raw ) {
			return array();
		}
		$items = json_decode( $raw, true );
		if ( ! is_array( $items ) ) {
			return array();
		}
		$out = array();
		foreach ( $items as $it ) {
			if ( empty( $it['q'] ) || empty( $it['a'] ) ) {
				continue;
			}
			$out[] = array(
				'@type'          => 'Question',
				'name'           => wp_strip_all_tags( $it['q'] ),
				'acceptedAnswer' => array(
					'@type' => 'Answer',
					'text'  => wp_kses_post( $it['a'] ),
				),
			);
		}
		return $out;
	}
}
